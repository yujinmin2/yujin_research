---
title: "EEG (뇌전도)"
---

# 🧠 EEG (Electroencephalography)

> 두피에서 측정하는 뇌 전기 신호

---

## 📖 정의

**EEG (뇌전도)**는 두피에 부착한 전극으로 뇌의 전기적 활동을 측정하는 비침습적 기술입니다.

---

## 📊 특성

| 특성 | 값 |
|------|-----|
| **공간 해상도** | ~1-2 cm |
| **시간 해상도** | ~1 ms |
| **침습성** | 비침습 |
| **채널 수** | 16-256+ |
| **주파수 범위** | 0.5-100 Hz |

---

## 🌊 주파수 대역

| 대역 | 주파수 | 상태 |
|------|--------|------|
| **Delta (δ)** | 0.5-4 Hz | 깊은 수면 |
| **Theta (θ)** | 4-8 Hz | 졸음, 명상 |
| **Alpha (α)** | 8-13 Hz | 이완, 눈 감음 |
| **Beta (β)** | 13-30 Hz | 집중, 활성 |
| **Gamma (γ)** | 30-100 Hz | 고차 인지 |

---

## 🎯 BCI 응용

```{mermaid}
flowchart LR
    EEG[EEG 신호] --> P[전처리<br/>필터링, ICA]
    P --> F[특징 추출<br/>PSD, ERP]
    F --> C[분류기<br/>SVM, CNN]
    C --> A[명령<br/>커서, 휠체어]
```

---

## 🔗 관련 개념

- [ECoG](ecog) - 더 높은 해상도
- [Intracortical](intracortical) - 침습적
- [BCI Decoder](bci-decoder)

---

## 📚 관련 수업

- [W8D1: BCI Systems](../courses/bci-basics/week8/day1-bci-systems)
- [W8D2: Future Directions](../courses/bci-basics/week8/day2-future-directions)
