---
title: "시냅스 (Synapse)"
---

# 🔗 시냅스 (Synapse)

> 뉴런 간 정보 전달 연결부

---

## 📖 정의

**시냅스**는 한 뉴런에서 다른 뉴런(또는 근육/분비세포)으로 신호를 전달하는 특수화된 연결 구조입니다.

---

## 🧬 구조

```{mermaid}
flowchart LR
    PRE[시냅스전 뉴런] --> |축삭 말단| CLEFT[시냅스 틈<br/>~20nm]
    CLEFT --> |수용체| POST[시냅스후 뉴런]
    
    style CLEFT fill:#f39c12
```

---

## ⚡ 유형

| 유형 | 전달 방식 | 속도 |
|------|----------|------|
| **화학적 시냅스** | 신경전달물질 | 느림 (~1ms) |
| **전기적 시냅스** | 갭 정션 | 빠름 (~0.1ms) |

---

## 🔗 관련 개념

- [뉴런](neuron)
- [신경전달물질](neurotransmitter)
- [STDP](stdp)

---

## 📚 관련 수업

- [W1D1: Introduction & Neurobiology](../courses/bci-basics/week1/day1-intro-neurobiology)
- [W6D1: Synaptic Models](../courses/bci-basics/week6/day1-synaptic-models)
