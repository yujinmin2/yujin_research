---
## 💬 댓글 & 피드백

질문이나 의견이 있으시면 아래에 남겨주세요!

<script src="https://giscus.app/client.js"
        data-repo="yujinmin2/yujin_research"
        data-repo-id="YOUR_REPO_ID"
        data-category="General"
        data-category-id="YOUR_CATEGORY_ID"
        data-mapping="pathname"
        data-strict="1"
        data-reactions-enabled="1"
        data-emit-metadata="0"
        data-input-position="bottom"
        data-theme="preferred_color_scheme"
        data-lang="ko"
        crossorigin="anonymous"
        async>
</script>
<noscript>댓글을 보려면 JavaScript를 활성화해주세요.</noscript>
